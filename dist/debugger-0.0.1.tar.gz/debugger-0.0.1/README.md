# PyDebugger
Simple python program to make printing, logging and debugging easier.