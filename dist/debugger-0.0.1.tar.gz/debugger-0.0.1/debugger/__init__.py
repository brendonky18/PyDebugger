from _debugger import Debugger

def wha():
    print("wha")